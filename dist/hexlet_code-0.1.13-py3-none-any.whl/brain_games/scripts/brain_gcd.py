#!/usr/bin/env python
import brain_games.games.third_exercise


def main():
    brain_games.games.third_exercise.repit_task()


if __name__ == '__main__':
    main()
    