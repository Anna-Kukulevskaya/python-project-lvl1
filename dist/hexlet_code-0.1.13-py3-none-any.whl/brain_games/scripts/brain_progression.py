#!/usr/bin/env python
import brain_games.games.fourth_exercise


def main():
    brain_games.games.fourth_exercise.repit_task()


if __name__ == '__main__':
    main()
    